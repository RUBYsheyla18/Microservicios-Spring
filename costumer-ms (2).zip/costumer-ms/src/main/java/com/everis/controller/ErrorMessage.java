package com.everis.controller;

public class ErrorMessage {

	public static Object builder() {
		// TODO Auto-generated method stub
		return null;
	}

}
