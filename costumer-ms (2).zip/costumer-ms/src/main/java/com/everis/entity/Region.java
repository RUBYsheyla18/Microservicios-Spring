package com.everis.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor @NoArgsConstructor @Builder
public class Region implements Serializable {
	public Region() {
		// TODO Auto-generated constructor stub
	}
	
	public Region(Long id, String name) {
		this.id = id;
		this.name = name;
	}
	private static final long serialVersionUID = 1L; 
	private Long id;  
	private String name; 

	public String getName()
	{
		return name;
	}
	
	public void setId(Long id)
	{
		this.id = id;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}

	public Long getId() {
		// TODO Auto-generated method stub
		return id;
	}


}