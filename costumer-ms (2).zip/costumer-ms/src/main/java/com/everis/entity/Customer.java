package com.everis.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Data
@AllArgsConstructor @NoArgsConstructor @Builder
public class Customer implements Serializable {

private static final long serialVersionUID = 1L; 

private Long id; 

    @NotEmpty(message = "El número de documento no puede ser vacío")
    @Size( min = 8 , max = 8, message = "El tamaño del número de documento es 8")
    private String numberID;

    @NotEmpty(message = "El nombre no puede ser vacío")
    private String firstName;
 
    @NotEmpty(message = "El apellido no puede ser vacío")
    private String lastName;

    @NotEmpty(message = "el correo no puede estar vacío")
    @Email(message = "no es un dirección de correo bien formada")
    private String email;

    private String photoUrl;

    @NotNull(message = "la región no puede ser vacia")
    private Region region;

    private String state;

/// metodos get y set
    
    public Customer(long id, String numberID, String firstName, String lastName, String email, String photoUrl, Region region,
			String state) {
		this.id= id;
		this.numberID=numberID;
		this.firstName =firstName;
		this.lastName = lastName;
		this.email = email;
		this.photoUrl = photoUrl;
		this.region = region;
		this.state = state;
		
	}

	public Long getId(){return id;}
    
    public String getNumberID(){return numberID;}

    public String getFirstName(){return firstName;}
 
    public String getLastName(){return lastName;}

    public String getEmail(){return email;}

    public String getPhotoUrl(){return photoUrl;}

    public Region getRegion(){return region;}

    public String getState(){return state;}
    
    
    
    public void setNumberID(String numberID){this.numberID = numberID;}
    
    public void setId(Long id){this.id = id;}

    public void setFirstName(String firstName){this.firstName = firstName;}
 
    public void setLastName(String lastName){this.lastName = lastName;}

    public void setEmail(String email){this.email = email;}

    public void setPhotoUrl(String photoUrl){this.photoUrl = photoUrl;}

    public void setRegion(Region region){this.region = region;}

    public void setState(String state){this.state = state;}

	
} 