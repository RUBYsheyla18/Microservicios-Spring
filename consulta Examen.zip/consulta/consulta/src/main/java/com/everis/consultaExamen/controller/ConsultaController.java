package com.everis.consultaExamen.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.everis.consultaExamen.service.ConsultaService;
import com.everis.consultaExamen.entity.Consulta;
import com.everis.consultaExamen.entity.Medico;
import com.everis.consultaExamen.entity.Paciente;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/consultas")

public class ConsultaController {
	
	@Autowired
	private ConsultaService consultaService;
	
	@GetMapping
	public ResponseEntity<List<Consulta>> listConsulta(@RequestParam(name="medicoId", required = false) Long medicoId) {
		List<Consulta> consultas = null;
		if(medicoId == null) {
			consultas = consultaService.listAllConsultas();
			 if(consultas.isEmpty()) {
					return ResponseEntity.notFound().build();
			 }
		}else {
			consultas = consultaService.findConsultasByMedicoID(Medico.builder().idMedico(medicoId).build());
			 if(consultas.isEmpty()) {
					return ResponseEntity.notFound().build();
			}
		}

		return ResponseEntity.ok(consultas);
	}
	
	@PostMapping
	public ResponseEntity<Consulta> createConsulta(@RequestBody Consulta consulta) {
		Consulta consultaCreate = consultaService.createConsulta(consulta);
		return ResponseEntity.ok(consultaCreate);		
	}
	
	@GetMapping
	public ResponseEntity<List<Consulta>> listDetalleConsulta(@RequestParam(name="pacienteId", required = false) Long pacienteId) {
		List<Consulta> consultas = null;
		if(pacienteId == null) {
			consultas = consultaService.listAllConsultas();
			 if(consultas.isEmpty()) {
					return ResponseEntity.notFound().build();
			 }
		}else {
			consultas = consultaService.findConsultasByPacienteID(Paciente.builder().idPaciente(pacienteId).build());
			 if(consultas.isEmpty()) {
					return ResponseEntity.notFound().build();
			}
		}

		return ResponseEntity.ok(consultas);
	}
}
