package com.everis.consultaExamen.controller;

public class DetalleConsultaController {

}
