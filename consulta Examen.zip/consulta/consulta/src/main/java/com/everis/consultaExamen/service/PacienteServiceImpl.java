package com.everis.consultaExamen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.everis.consultaExamen.entity.Paciente;
import com.everis.consultaExamen.repository.PacienteRepository;



public class PacienteServiceImpl implements PacienteService{
	@Autowired
    PacienteRepository PacienteRepository;

    @Override
    public List<Paciente> findPacienteAll() {
        return PacienteRepository.findAll();
    }

    @Override
    public Paciente createPaciente(Paciente Paciente) { 

        Paciente PacienteDB = PacienteRepository.findPacienteById(Paciente.getIdPaciente());
        if (PacienteDB != null){
            return  PacienteDB;
        }

        PacienteDB = PacienteRepository.save(Paciente);
        return PacienteDB;
    }

    @Override
    public Paciente updatePaciente(Paciente Paciente) {
        Paciente PacienteDB = getPaciente(Paciente.getIdPaciente());
        if (PacienteDB == null){
            return  null;
        }
        PacienteDB.setNombres(Paciente.getNombres());
        PacienteDB.setApellidos(Paciente.getApellidos());
        PacienteDB.setDNI(Paciente.getDNI());
        PacienteDB.setDireccion(Paciente.getDireccion());
        PacienteDB.setEmail(Paciente.getEmail());
        PacienteDB.setTelefono(Paciente.getTelefono());

        return  PacienteRepository.save(PacienteDB);
    }

    @Override
    public Paciente deletePaciente(Paciente Paciente) {
        Paciente PacienteDB = getPaciente(Paciente.getIdPaciente());
        if (PacienteDB ==null){
            return  null;
        }
        return PacienteRepository.save(Paciente);
    }

    @Override
    public Paciente getPaciente(Long id) {
        return  PacienteRepository.findPacienteById(id);
    }
}
