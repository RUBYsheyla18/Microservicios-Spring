package com.everis.consultaExamen.controller;

public class PacienteController {

}
