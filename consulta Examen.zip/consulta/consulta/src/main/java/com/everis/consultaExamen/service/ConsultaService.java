package com.everis.consultaExamen.service;

import java.util.List;

import com.everis.consultaExamen.entity.Consulta;
import com.everis.consultaExamen.entity.DetalleConsulta;
import com.everis.consultaExamen.entity.Medico;
import com.everis.consultaExamen.entity.Paciente;
import com.everis.consultaExamen.entity.Especialidad;



public interface ConsultaService {
	public List<Consulta> listAllConsultas(); 
	public List<Consulta> findConsultasByMedicoID(Medico medico);
	public List<Consulta> findConsultasByEspecialidad(Especialidad especialidad);
	public List<Consulta> findConsultasByPacienteID(Paciente paciente);
	
	
    public Consulta createConsulta(Consulta Consulta);
    public Consulta updateConsulta(Consulta Consulta);
    public Consulta deleteConsulta(Consulta Consulta);
    public Consulta getConsulta(Long id);
}
