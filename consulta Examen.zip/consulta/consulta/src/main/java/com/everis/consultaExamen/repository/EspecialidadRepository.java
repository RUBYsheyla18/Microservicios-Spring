package com.everis.consultaExamen.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.everis.consultaExamen.entity.Especialidad;

public interface EspecialidadRepository extends JpaRepository<Especialidad, Long>{
	
	public Especialidad findByNumberID(String idEspecialidad);
		
	@Query(value = "select * from tbl_especialidades p where p.id = :id", nativeQuery = true)
	public Especialidad findEspecialidadById(@Param("id") Long id);


}