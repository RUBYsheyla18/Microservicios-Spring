package com.everis.consultaExamen.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.everis.consultaExamen.entity.Paciente;

public interface PacienteRepository extends JpaRepository<Paciente, Long>{
	
	public Paciente findByIdPaciente(String idPaciente);
		
	@Query(value = "select * from tbl_pacientes p where p.id = :id", nativeQuery = true)
	public Paciente findPacienteById(@Param("id") Long id);

}
