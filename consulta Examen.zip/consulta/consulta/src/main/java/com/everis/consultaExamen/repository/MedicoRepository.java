package com.everis.consultaExamen.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.everis.consultaExamen.entity.Medico;

@Repository
public interface MedicoRepository extends JpaRepository<Medico, Long>{
			
	public Medico findByNumberID(String idMedico);
			
	@Query(value = "select * from tbl_medicos p where p.id = :id", nativeQuery = true)
	public Medico findMedicoById(@Param("id") Long id);
}
