package com.everis.consultaExamen.entity;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
	@AllArgsConstructor
	@NoArgsConstructor
	@Builder
	@Entity
	@Table(name = "tbl_pacientes")
	
	public class Paciente implements Serializable {

	private static final long serialVersionUID = 1L; 

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_paciente")
	private Long idPaciente;

	
	@NotEmpty(message = "El número de documento no puede ser vacío")
	@Size( min = 8 , max = 8, message = "El tamaño del número de documento es 8")
	private String DNI;

	    @NotEmpty(message = "El nombre no puede ser vacío")
	    private String nombres;
	 
	    @NotEmpty(message = "El apellido no puede ser vacío")
	    private String apellidos;
	    
	    @NotEmpty(message = "La direccion no puede ser vacío")
	    private String direccion;
	    
	    @NotEmpty(message = "el correo no puede estar vacío")
	    @Email(message = "no es un dirección de correo bien formada")
	    private String email;

	    
	    @NotEmpty(message = "El número de telefono no puede ser vacío")
		@Size( min = 9 , max = 9, message = "El tamaño de telefono es 9")
	    private String telefono;
	    

		
	} 

