package com.everis.consultaExamen.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.everis.consultaExamen.entity.DetalleConsulta;

public interface DetalleConsultaRepository extends JpaRepository<DetalleConsulta, Long>{
	
	public DetalleConsulta findByNumberID(String idDetalleConsulta);
		
	@Query(value = "select * from tbl_detalles_consultas p where p.id = :id", nativeQuery = true)
	public DetalleConsulta findDetalleConsultaById(@Param("id") Long id);


}
