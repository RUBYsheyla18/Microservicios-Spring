package com.everis.consultaExamen.service;

import java.util.List;

import com.everis.consultaExamen.entity.DetalleConsulta;
import com.everis.consultaExamen.entity.Paciente;


public interface DetalleConsultaService {
	public List<DetalleConsulta> findConsultaAll();
	public List<DetalleConsulta> findDetalleConsultaByPaciente(Paciente paciente);
	

    public DetalleConsulta createDetalleConsulta(DetalleConsulta detalleConsulta);
    public DetalleConsulta updateDetalleConsulta(DetalleConsulta detalleConsulta);
    public DetalleConsulta deleteDetalleConsulta(DetalleConsulta detalleConsulta);
    public DetalleConsulta getDetalleConsulta(Long id);
}
