package com.everis.consultaExamen.service;

import java.util.List;

import com.everis.consultaExamen.entity.Medico;

public interface MedicoService {
	public List<Medico> findMedicoAll();
	
    public Medico createMedico(Medico Medico);
    public Medico updateMedico(Medico Medico);
    public Medico deleteMedico(Medico Medico);
    public Medico getMedico(Long id);
}
