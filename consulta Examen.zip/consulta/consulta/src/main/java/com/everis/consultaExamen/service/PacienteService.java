package com.everis.consultaExamen.service;

import java.util.List;

import com.everis.consultaExamen.entity.Paciente;

public interface PacienteService {
	public List<Paciente> findPacienteAll();
		
    public Paciente createPaciente(Paciente Paciente);
    public Paciente updatePaciente(Paciente Paciente);
    public Paciente deletePaciente(Paciente Paciente);
    public Paciente getPaciente(Long id);
}
