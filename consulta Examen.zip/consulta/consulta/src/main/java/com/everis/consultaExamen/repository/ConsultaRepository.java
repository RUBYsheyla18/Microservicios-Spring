package com.everis.consultaExamen.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.everis.consultaExamen.entity.Consulta;
import com.everis.consultaExamen.entity.Medico;
import com.everis.consultaExamen.entity.Paciente;

public interface ConsultaRepository extends JpaRepository<Consulta, Long>{
	
public Consulta findByConsultaID(Long idconsulta);
	
    
    public List<Consulta> findByMedico(Medico medico);
    public List<Consulta> findByPaciente(Paciente paciente);


}
