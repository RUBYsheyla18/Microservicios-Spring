package com.everis.consultaExamen.service;

import java.util.List;

import com.everis.consultaExamen.entity.Especialidad;

public interface EspecialidadService {
	public List<Especialidad> findConsultaAll();

    public Especialidad createEspecialidad(Especialidad Especialidad);
    public Especialidad Especialidad(Especialidad Especialidad);
    public Especialidad deleteEspecialidad(Especialidad Especialidad);
    public Especialidad getConsulta(Long id);
}
