package com.everis.consultaExamen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.everis.consultaExamen.entity.Consulta;
import com.everis.consultaExamen.entity.Especialidad;
import com.everis.consultaExamen.entity.Medico;
import com.everis.consultaExamen.entity.Paciente;
import com.everis.consultaExamen.repository.ConsultaRepository;

@Service
public class ConsultaServiceImpl implements ConsultaService{
	@Autowired
    ConsultaRepository consultaRepository;

    @Override
    public List<Consulta> listAllConsultas() {
        return consultaRepository.findAll();
    }

    @Override
    public List<Consulta> findConsultasByMedicoID(Medico medico) {
        return consultaRepository.findByMedico(medico);
    }
    
    @Override
	public Consulta createConsulta(Consulta consulta) {
            Consulta consultaDB = consultaRepository.findByConsultaID(consulta.getIdConsulta());
            if (consultaDB != null){
                return  consultaDB;
            }
            consultaDB = consultaRepository.save ( consulta );
            return consultaDB;
	}
    
    @Override
    public List<Consulta> findConsultasByPacienteID(Paciente paciente) {
        return consultaRepository.findByPaciente(paciente);
    }

	@Override
	public List<Consulta> findConsultasByEspecialidad(Especialidad especialidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Consulta updateConsulta(Consulta Consulta) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Consulta deleteConsulta(Consulta Consulta) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Consulta getConsulta(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
}
