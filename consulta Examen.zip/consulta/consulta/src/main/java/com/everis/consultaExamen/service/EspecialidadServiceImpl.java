package com.everis.consultaExamen.service;

public class EspecialidadServiceImpl {

}
