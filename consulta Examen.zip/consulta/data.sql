INSERT INTO tbl_consultas(id_consulta,fecha,id_medico,id_paciente,id_especialidad,id_detalle) VALUES (1,'2020-01-01',10,10,11,45786577);
INSERT INTO tbl_consultas(id_consulta,fecha,id_medico,id_paciente,id_especialidad,id_detalle) VALUES (2,'2020-02-02',12,11,10,45786574);
INSERT INTO tbl_consultas(id_consulta,fecha,id_medico,id_paciente,id_especialidad,id_detalle) VALUES (3,'2020-03-01',15,12,12,45786597);

INSERT INTO tbl_detalleconsulta(id_detalle,diagnostico,tratatiemto)
VALUES (45786577,'gastritis','omeprazol'); 
INSERT INTO tbl_detalleconsulta(id_detalle,diagnostico,tratatiemto)
VALUES (45786574,'cancer','quimioterapia'); 
INSERT INTO tbl_detalleconsulta(id_detalle,diagnostico,tratatiemto)
VALUES (45786597,'anemia','hierro'); 

INSERT INTO tbl_medicos(id_medico,nombres,apellidos,cmp)
VALUES (10,'Oscar','Quispe','120123'); 
INSERT INTO tbl_medicos(id_medico,nombres,apellidos,cmp)
VALUES (11,'Ruby','Zela','120133'); 
INSERT INTO tbl_medicos(id_medico,nombres,apellidos,cmp)
VALUES (12,'Barbara','Galarreta','140123'); 
INSERT INTO tbl_medicos(id_medico,nombres,apellidos,cmp)
VALUES (13,'Mario','Oretga','140133'); 
INSERT INTO tbl_medicos(id_medico,nombres,apellidos,cmp)
VALUES (14,'Juan','Hamilton','140723'); 
INSERT INTO tbl_medicos(id_medico,nombres,apellidos,cmp)
VALUES (15,'Mario','Quispe','190123'); 

INSERT INTO tbl_pacientes(id_paciente,nombres,apellidos,dni,direccion,telefono,email)
VALUES (10,'Quispe','Albertos','48760412','apv. qosqorunas','970242094','130109@gmail.com'); 
INSERT INTO tbl_pacientes(id_paciente,nombres,apellidos,dni,direccion,telefono,email)
VALUES (11,'Ruby','Zela','48760410','apv. qosqorunas','970242094','130733@gmail.com'); 
INSERT INTO tbl_pacientes(id_paciente,nombres,apellidos,dni,direccion,telefono,email)
VALUES (12,'Edgard','Caceres','48760411','apv. qosqorunas','970242094','130735@gmail.com'); 

INSERT INTO tbl_especialidades(id_especialidad,nombre)
VALUES (10,'general'); 
INSERT INTO tbl_especialidades(id_especialidad,nombre)
VALUES (11,'cirugia'); 
INSERT INTO tbl_especialidades(id_especialidad,nombre)
VALUES (12,'neurologia'); 

