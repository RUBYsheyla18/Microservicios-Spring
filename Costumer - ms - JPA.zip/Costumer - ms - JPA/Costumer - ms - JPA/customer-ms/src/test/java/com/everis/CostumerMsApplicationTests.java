package com.everis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CostumerMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
